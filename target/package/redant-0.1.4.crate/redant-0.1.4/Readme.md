<h1>
redant <img style="vertical-align:middle;" alt="logo" src="https://i.imgur.com/7U4ktuT.png?1" height="25px">
</h1>

Generate a random combination of color and creature. Userful in naming objects, modules, packages, libraries (like this one).



---


<div align="center">
  <h4>
    <a href="https://hamzamohdzubair.github.io/redant/">
      Guide
    </a>
    <span> | </span>
    <a href="https://docs.rs/crate/redant/latest">
      API
    </a>
    <span> | </span>
    <a href="https://crates.io/crates/redant">
      Crates.io
    </a>
    <span> | </span>
    <a href="https://lib.rs/crates/redant">
      Lib.rs
    </a>
  </h4>
</div>

---

## License

MIT